<template>
  <div>
 <hello-metamask/>
</div>
</template>
<script>
import HelloMetamask from '@/components/poolDapp/hello-metamask'
export default {
  name: 'pool-dapp',
  beforeCreate () {
    console.log('registerWeb3 Action dispatched from pool-dapp.vue')
    this.$store.dispatch('registerWeb3')
    this.$store.dispatch('getContractInstance')
  },
  components: {
    'hello-metamask': HelloMetamask
  }
}
</script>
<style scoped>
</style>